import data2

from data2 import a_team, b_team, c_team, people


def get_people(team):

	name_list =  []

	for name in team.members:

		if name.id <= 12:
			name_list.append(name.displayname)

		elif name.id == 90:
			for member in a_team.members:
				if member.displayname not in name_list:
					name_list.append(member.displayname)

		elif name.id == 91:
			for member in b_team.members:
				if member.displayname not in name_list:
					name_list.append(member.displayname)

		elif name.id == 92:
			for member in c_team.members:
				if member.displayname not in name_list:
					name_list.append(member.displayname)

		else:
			print "Name id is not defined..."

	name_list = sorted(name_list)

	return name_list



print get_people(c_team)