from data2 import alice, people

def check_team(name, *people):

	team_list = list()

	for person in people:

		if person.is_team == True:

			team_list.append(person.displayname)
	
	return team_list



print check_team(alice, *people)