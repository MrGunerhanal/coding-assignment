from data1 import alice, people
# from data2 import alice, people

def check_team(name, *people): 

	team_list = []

	for person in people:

		if person.is_team is True:

			team_list.append(person.displayname)

	return team_list


print check_team(alice, *people)

''' 
Firstly, we create a function named check_team. Then we pass two args into our
functions. 

In Python, when we create a function we use "def" definition before the function 
name. Most languages use function word to define a function.

*people allow you to pass a variable number of arguments to a function. What variable
means here that you do not know beforehand how many arguments can be passed to your 
functions by the user. So in this case you these two keywords. *args
if you need to pass a named arguments, you will need to define your kwargs with double
stars. **kwargs.

You may probably know that everything in Python is Object. Hence, that includes all data
structures(int, string, boolean, list, tuples, dict)

We use for loops to iterate trough in the people list.

Every data structures have many methods which are been implemented in the standard library.

So, inside the for loops we use append method of list object, to add element into the 
team list. 

Finally we return team_list object.

'''